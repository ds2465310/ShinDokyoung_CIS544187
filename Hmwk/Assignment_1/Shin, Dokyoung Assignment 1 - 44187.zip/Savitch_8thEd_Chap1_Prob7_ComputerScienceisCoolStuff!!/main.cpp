/* 
  File:   main.cpp
  Author: Shin Dokyoung
  Created on February 27, 2017, 6:45 PM
  Purpose: Computer Science is Cool Stuff!!
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    
    //Input values
    
    //Process by mapping inputs to outputs
    
    //Output values
    cout << "*************************************************\n";
    cout << "\n";
    cout << "          C C C             S S S S        !!\n";
    cout << "         C      C         S         S      !!\n";
    cout << "        C                S                 !!\n";
    cout << "       C                  S                !!\n";
    cout << "       C                    S S S S        !!\n";
    cout << "       C                            S      !!\n";
    cout << "        C                            S     !!\n";
    cout << "         C      C         S         S        \n";
    cout << "          C C C             S S S S        00\n";
    cout << "\n";
    cout << "*************************************************\n";
    cout << "\n";
    cout << "    Computer Science is Cool Stuff!!!\n";
    
    //Exit stage right!
    
    
    return 0;
}